# Handoff: TCI Rebrand (formerly EU-CRI)

## Overview
A full visual rebrand of the Compute-Index project: new umbrella brand **TCI — The Compute Indices** (ticker family `TCI-CRI-*`, replacing `EU-CRI-*`), new dark theme, new type system. Covers all 5 public pages plus a standalone brand guide.

## About the design files
The `.dc.html` files in this folder are **design references**, built in a prototyping tool (hence the `<x-dc>` wrapper and `support.js` — open them in a browser to view/interact, they are not meant to be copied verbatim). Your actual site is **generated**, not hand-authored: `site/*.html` is produced by `src/eucri/outputs/site.py` from `data/eucri.db` on every `python -m eucri.run daily`, and styled by `site/assets/tokens.css` + `site/assets/site.css`. **The task is to port this visual system into that generator and stylesheet — not to replace the generated HTML with these static files.**

## Fidelity
High-fidelity. Exact colors, type, spacing and component treatments are specified below and should be reproduced pixel-for-precise.

## What changed vs. the current site
- Brand name: EU-CRI → **TCI** (The Compute Indices). Ticker prefix: `EU-CRI-*` → `TCI-CRI-*`.
- Visual system: light "cool-slate + teal" editorial system → **dark, near-black** ground with a two-tone red accent.
- Typography: system-ui/serif/mono triad → **Outfit** (display/UI) + **JetBrains Mono** (all data/figures).
- New elements: scrolling ticker banner, hover-animated wave/line graphic on the homepage hero, wordmark lockup ("TC" + a red-dotted bar standing in for "I").

## Design tokens

### Color
| Token | Value | Use for |
|---|---|---|
| Ground | `#0B0C0D` | Page background — the only page-background color |
| Surface | `#131416` / `#151619` | Cards, code/terminal blocks |
| Ink 1 | `#F5F5F6` | Headings, values, primary text |
| Ink 2 | `rgba(245,245,246,.6)` | Body copy |
| Ink 3 | `rgba(245,245,246,.4)` | Labels, captions, timestamps |
| Border | `rgba(255,255,255,.08–.18)` | Hairlines, card borders (opacity varies by emphasis) |
| **Primary red (wine)** | `#650304` | **Large filled shapes only**: primary buttons, active nav CTA pill. Text on it is white. |
| **Bright red** | `#FF0000` | **Small marks only, rationed**: live-status dot (with pulse), ticker marker dots, the logo's dot, "Live" labels, delta/highlight text in code blocks. Never a fill for anything button-sized or larger. |

The one rule that matters: **big shapes get the dark wine, small marks get the bright red — never invert it.**

### Typography
- **Outfit** (Google Fonts, weights 400/500/600/700/800) — all headings and UI text.
- **JetBrains Mono** (Google Fonts, weights 400/500/600) — every number and data label: prices, ticker items, table figures, timestamps, code. Never for prose.
- Scale: H1 36–44px/700, H2 22–24px/600, Body 15–16px/400, Label 11px/600 uppercase, letter-spacing .06–.14em.

### Spacing & radius
- Base unit 4px. Common paddings: 12 / 16 / 22 / 24 / 48px.
- Radius: 6–10px on cards/buttons, 999px pill on the primary nav CTA.

### Motion (CSS keyframes — see `TCI Brand Guide.dc.html` §06 for full specs)
| Keyframe | Spec | Used for |
|---|---|---|
| `tci-pulse` | 2.2s ease-in-out infinite | Live-status dot only |
| `tci-marquee` | 24s linear infinite | Ticker banner scroll |
| `tci-fadeup` | .7s ease-out, staggered .1s | Hero entrance |
| `tci-rise` | 1.1s ease-out, staggered | Wave graphic draw-in on page load |
| `tci-wave` | 1.3–2s ease-in-out infinite, staggered | Wave graphic, hover only |

Motion is functional (live data / entrance / interaction feedback) — never decorative-only.

## Screens
1. **Landing / Dashboard** (`TCI Landing Page.dc.html`) — ticker banner, nav, hero with headline + the animated wave/line graphic (hover-triggered), headline series table, 3 methodology pillars, "family of indices" cards (current + in-development), data/API teaser with a terminal-style code block, research list, footer.
2. **Methodology** (`TCI Methodology.dc.html`) — reference definition table, compute-classes table, market-segment cards, a terminal-block explainer of the aggregation rules, change-control summary.
3. **Governance** (`TCI Governance.dc.html`) — regulatory-scope callout, settlement-grade preconditions checklist, policy-summary card grid, complaints contact.
4. **Data & Downloads** (`TCI Data.dc.html`) — download cards (CSV/JSON/audit/API), terminal code sample, terms-of-use summary table, attribution citation format.
5. **Research** (`TCI Research.dc.html`) — post list, subscribe box.
6. **Brand Guide** (`TCI Brand Guide.dc.html`) — the full system reference (logo construction/clearspace/do-don't, full color table, type scale, spacing, component specimens, motion table, voice rules). Treat this as the source of truth for tokens.

All 5 site pages share the same header (ticker + nav + logo) and footer (4-column link grid + legal line) — implement these once as shared partials/includes in the generator, not per-page.

## Responsive / mobile behavior
All 5 page designs now include a mobile layout (breakpoint: `max-width: 760px`). Implement these rules in `site.css`, not just the desktop styles:

- **Nav**: collapses to logo + hamburger. Reference implementation is a checkbox+label CSS toggle (no JS) — `input[type=checkbox]#tci-nav-toggle` (visually hidden) + a `<label for>` hamburger icon; the link list and the "View Indices" CTA are shown via a `:checked ~ sibling` selector. Port the same pattern or your framework's equivalent (e.g. a `useState` toggle in React).
- **Grids collapse to 1 column** below 760px: methodology pillars, indices-family cards, market-segment cards, download cards, governance policy cards. Footer's 4-column link grid collapses to 2 columns (not 1).
- **Hero**: the animated wave/line graphic behind the headline is hidden on mobile (`display:none`) — the hero becomes text-only, full width.
- **Headings**: H1 scales down (desktop 40–44px → mobile ~28–30px) to stay comfortable at phone widths.
- **Tables**: wrapped in a horizontally-scrollable container (`overflow-x:auto`, `min-width` on the table itself) rather than reflowing columns — the headline-series, reference-definition, compute-classes, preconditions and terms tables all use this.
- **Section padding**: horizontal padding drops from 48px to 20px on mobile; vertical rhythm is unchanged.

See the class names `tci-navbar`, `tci-nav-toggle`, `tci-nav-links`, `tci-cta`, `tci-grid-2/3/4`, `tci-footer-grid`, `tci-hero-wave`, `tci-hero-h1`, `tci-page-h1`, `tci-sec`, `tci-table-wrap` in the `.dc.html` files and their `<style>` block for the exact selectors/values — they're a direct implementation guide, not just a naming suggestion.

## Content notes
Copy in the mockups was drawn from the repo's own docs (README.md, METHODOLOGY.md, GOVERNANCE.md, DATA-TERMS.md, config/factors.yaml) to stay factually consistent — but it is illustrative, not final. Live numbers (prices, deltas, dates) should keep coming from the real pipeline/`latest.json`, not be hardcoded.

## Assets
No external images — everything is CSS/inline SVG/DOM (dots, bars, gradients). No new asset files needed beyond the two Google Fonts.

## Files in this folder
- `TCI Landing Page.dc.html`, `TCI Methodology.dc.html`, `TCI Governance.dc.html`, `TCI Data.dc.html`, `TCI Research.dc.html` — the 5 page designs.
- `TCI Brand Guide.dc.html` — full token/component/motion/voice reference.
- `support.js` — runtime the `.dc.html` files need to render in a browser; keep it alongside them if you open the files directly, it is **not** part of your actual site.
